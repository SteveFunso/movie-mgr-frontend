import React, { useState, useEffect } from "react";
import axios from "../axios";
import { Link } from "react-router-dom";

const MoviesList = () => {
  const [movies, setMovies] = useState([]);

  useEffect(() => {
    axios
      .get("/movies")
      .then((response) => setMovies(response.data))
      .catch((error) => console.error("Error fetching movies:", error));
  }, []);

  return (
    <div>
      <h1>Movies</h1>
      <Link to="/movies/create">Create Movie</Link>
      <ul>
        {movies.map((movie) => (
          <li key={movie.id}>
            <Link to={`/movies/${movie.slug}`}>{movie.name}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default MoviesList;
