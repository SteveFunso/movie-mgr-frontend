import React, { useState, useEffect } from "react";
import axios from "../axios";
import { useParams } from "react-router-dom";

const MovieDetail = () => {
  const { slug } = useParams();
  const [movie, setMovie] = useState(null);
  const [comments, setComments] = useState([]);
  const [comment, setComment] = useState("");

  useEffect(() => {
    const fetchMovie = async () => {
      try {
        const response = await axios.get(`/movies/${slug}`);
        setMovie(response.data);
        fetchComments(response.data.id); // Fetch comments using movie ID
      } catch (error) {
        console.error("Error fetching movie:", error);
      }
    };

    const fetchComments = async (movieId) => {
      try {
        const response = await axios.get(`/comments/${movieId}`);
        setComments(response.data);
      } catch (error) {
        console.error("Error fetching comments:", error);
      }
    };

    fetchMovie();
  }, [slug]);

  const handleCommentSubmit = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem("token");
    try {
      const response = await axios.post(
        "/comments",
        {
          comment,
          movieId: movie.id,
        },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      setComments([...comments, response.data]);
      setComment("");
    } catch (error) {
      console.error("Error posting comment:", error);
    }
  };

  if (!movie) return <div>Loading...</div>;

  return (
    <div>
      <h1>{movie.name}</h1>
      <p>{movie.description}</p>
      <p>Release Date: {movie.releaseDate}</p>
      <p>Rating: {movie.rating}</p>
      <p>Ticket Price: ${movie.ticketPrice}</p>
      <p>Country: {movie.country}</p>
      <p>Genres: {movie.genres.join(", ")}</p>
      <img src={movie.photo} alt={movie.name} />

      <h2>Comments</h2>
      <ul>
        {comments.map((comment) => (
          <li key={comment.id}>
            <strong>{comment.name}</strong>: {comment.comment}
          </li>
        ))}
      </ul>
      <form onSubmit={handleCommentSubmit}>
        <textarea
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          required
        />
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default MovieDetail;
