import React from "react";
import { Route, Routes, Navigate } from "react-router-dom";
import MoviesList from "./components/MoviesList";
import MovieDetail from "./components/MovieDetail";
import CreateMovie from "./components/CreateMovie";
import Login from "./components/Login";
import Register from "./components/Register";
import PrivateRoute from "./components/PrivateRoute";

const App = () => {
  return (
    <div className="App">
      <Routes>
        <Route path="/" element={<Navigate to="/movies" />} />
        <Route
          path="/movies"
          element={<PrivateRoute component={MoviesList} />}
        />
        <Route
          path="/movies/create"
          element={<PrivateRoute component={CreateMovie} />}
        />
        <Route
          path="/movies/:slug"
          element={<PrivateRoute component={MovieDetail} />}
        />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
      </Routes>
    </div>
  );
};

export default App;
